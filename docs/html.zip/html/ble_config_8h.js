var ble_config_8h =
[
    [ "BLECONFIGS_H", "ble_config_8h.html#a4bbd173ed413764eacf17c52a5b4e774", null ],
    [ "SERVICE_UUID", "ble_config_8h.html#a445125ee8c34695376c85f10b38844d6", null ],
    [ "EncerrarBLE", "ble_config_8h.html#a9f566969550d007df837c1490bb6316b", null ],
    [ "IniciarBLE", "ble_config_8h.html#a5c0efe429f3a4ddda46992fd1c9e08fc", null ],
    [ "deviceConnected", "ble_config_8h.html#a5affc02c6814932fa2696bac53bc2598", null ]
];