var funcoes_8h =
[
    [ "botaoISR", "funcoes_8h.html#a98f1875fb179306f570060a93476cf21", null ],
    [ "CarregarConfig", "funcoes_8h.html#ae37aeb6cc3ac00302fef48cad121e04a", null ],
    [ "ConectaWifi", "funcoes_8h.html#a420a08393185ceba2855a2de10715128", null ],
    [ "DesconectaWifi", "funcoes_8h.html#ac0864cde0bddc4d52913c6a7215a85c8", null ],
    [ "EnviarWeb", "funcoes_8h.html#a496d1413601446647f4f6e259120b832", null ],
    [ "EnviarWhats", "funcoes_8h.html#aab7876312534d1d5cb2b52368d8a66aa", null ],
    [ "SalvaConfig", "funcoes_8h.html#a10c0866444677cfc520f43e52f3b763a", null ],
    [ "apiKey", "funcoes_8h.html#abafd9aa183f18bceec5da61aa1f93a87", null ],
    [ "apiWhats", "funcoes_8h.html#a2178705e4b75e3811fb805ea29271cd6", null ],
    [ "botaoLastTime", "funcoes_8h.html#aea6cbc4ff8e3879ccf35d8f8d5f7ad7d", null ],
    [ "botaoTime", "funcoes_8h.html#ac8b87eeeb2a6a065bbfb0fd654328442", null ],
    [ "flagBle", "funcoes_8h.html#adf204609b938686fca6dcd5c6b7145f9", null ],
    [ "intervaloTemp", "funcoes_8h.html#a0410997c46ed3194dd285765f7f31860", null ],
    [ "nomeWifi", "funcoes_8h.html#a1985d05d19fdca8123f77df57639188f", null ],
    [ "numCelular", "funcoes_8h.html#ae5f1bf82db9796145db3a408488ecefd", null ],
    [ "prefs", "funcoes_8h.html#a77f70a9d88156f5f7dbdd99bfaaee64e", null ],
    [ "senhaWifi", "funcoes_8h.html#a2b53c380928d42395504a2470d0e10e6", null ],
    [ "server", "funcoes_8h.html#a4cfa213c7b6b7e5a1788f5bf87b423d8", null ],
    [ "setpointTemp", "funcoes_8h.html#add1d9118be43175094da2653b50c9f78", null ]
];