var files_dup =
[
    [ "lib", "dir_97aefd0d527b934f1d99a682da8fe6a9.html", "dir_97aefd0d527b934f1d99a682da8fe6a9" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ]
];