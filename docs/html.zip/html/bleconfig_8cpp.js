var bleconfig_8cpp =
[
    [ "MyServerCallbacks", "class_my_server_callbacks.html", "class_my_server_callbacks" ],
    [ "EncerrarBLE", "bleconfig_8cpp.html#a9f566969550d007df837c1490bb6316b", null ],
    [ "IniciarBLE", "bleconfig_8cpp.html#a5c0efe429f3a4ddda46992fd1c9e08fc", null ],
    [ "IntervaloChar", "bleconfig_8cpp.html#a28d7460209c71220475c726e58b7d90b", null ],
    [ "IntervaloDesc", "bleconfig_8cpp.html#a6631abdf9342c486ac682344cdb0baba", null ],
    [ "TemperaturaChar", "bleconfig_8cpp.html#ad67a7974fa10bc5742f3e1c5719bdf0b", null ],
    [ "TemperaturaDesc", "bleconfig_8cpp.html#a0962a981d8b0fee9f4d0af772bdd319e", null ],
    [ "WifiNomeChar", "bleconfig_8cpp.html#a36b06be8e7e69a1bcfba370b1683a854", null ],
    [ "WifiNomeDesc", "bleconfig_8cpp.html#a796c95a5f393a0b35df0662a34d87793", null ],
    [ "WifiSenhaChar", "bleconfig_8cpp.html#afc0060aea761b2f271bcb66ccd8d8e88", null ],
    [ "WifiSenhaDesc", "bleconfig_8cpp.html#a4393c035390ec7c37282009cedb4d801", null ]
];