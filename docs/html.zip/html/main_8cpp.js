var main_8cpp =
[
    [ "loop", "main_8cpp.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "PinOneWire", "main_8cpp.html#a150087f953fda6915d3f1a40555feb3f", null ],
    [ "setup", "main_8cpp.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "apiKey", "main_8cpp.html#abafd9aa183f18bceec5da61aa1f93a87", null ],
    [ "apiWhats", "main_8cpp.html#a2178705e4b75e3811fb805ea29271cd6", null ],
    [ "botaoLastTime", "main_8cpp.html#aea6cbc4ff8e3879ccf35d8f8d5f7ad7d", null ],
    [ "botaoTime", "main_8cpp.html#ac8b87eeeb2a6a065bbfb0fd654328442", null ],
    [ "count", "main_8cpp.html#ad43c3812e6d13e0518d9f8b8f463ffcf", null ],
    [ "deviceConnected", "main_8cpp.html#a5affc02c6814932fa2696bac53bc2598", null ],
    [ "flagBle", "main_8cpp.html#adf204609b938686fca6dcd5c6b7145f9", null ],
    [ "intervaloTemp", "main_8cpp.html#a0410997c46ed3194dd285765f7f31860", null ],
    [ "nomeWifi", "main_8cpp.html#a1985d05d19fdca8123f77df57639188f", null ],
    [ "numCelular", "main_8cpp.html#ae5f1bf82db9796145db3a408488ecefd", null ],
    [ "PinOneWire", "main_8cpp.html#a2281c25ce20f336862c9efd9b1cb272b", null ],
    [ "prefs", "main_8cpp.html#a77f70a9d88156f5f7dbdd99bfaaee64e", null ],
    [ "senhaWifi", "main_8cpp.html#a2b53c380928d42395504a2470d0e10e6", null ],
    [ "server", "main_8cpp.html#a4cfa213c7b6b7e5a1788f5bf87b423d8", null ],
    [ "setpointTemp", "main_8cpp.html#add1d9118be43175094da2653b50c9f78", null ],
    [ "TemperaturaChar", "main_8cpp.html#addaafdcebe086b82f5e22ac3ba9b50e2", null ],
    [ "ultimaTemp", "main_8cpp.html#a88c6be4f27423cb49670a683b86f1685", null ]
];