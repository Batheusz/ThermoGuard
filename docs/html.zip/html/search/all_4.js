var searchData=
[
  ['encerrarble_0',['EncerrarBLE',['../bleconfig_8cpp.html#a9f566969550d007df837c1490bb6316b',1,'EncerrarBLE():&#160;bleconfig.cpp'],['../ble_config_8h.html#a9f566969550d007df837c1490bb6316b',1,'EncerrarBLE():&#160;bleconfig.cpp']]],
  ['enviarweb_1',['EnviarWeb',['../funcoes_8cpp.html#a496d1413601446647f4f6e259120b832',1,'EnviarWeb(float valor):&#160;funcoes.cpp'],['../funcoes_8h.html#a496d1413601446647f4f6e259120b832',1,'EnviarWeb(float valor):&#160;funcoes.cpp']]],
  ['enviarwhats_2',['EnviarWhats',['../funcoes_8cpp.html#aab7876312534d1d5cb2b52368d8a66aa',1,'EnviarWhats(String mensagem):&#160;funcoes.cpp'],['../funcoes_8h.html#aab7876312534d1d5cb2b52368d8a66aa',1,'EnviarWhats(String mensagem):&#160;funcoes.cpp']]]
];
