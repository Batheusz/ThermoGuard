var searchData=
[
  ['desconectawifi_0',['DesconectaWifi',['../funcoes_8cpp.html#ac0864cde0bddc4d52913c6a7215a85c8',1,'DesconectaWifi():&#160;funcoes.cpp'],['../funcoes_8h.html#ac0864cde0bddc4d52913c6a7215a85c8',1,'DesconectaWifi():&#160;funcoes.cpp']]],
  ['deviceconnected_1',['deviceConnected',['../main_8cpp.html#a5affc02c6814932fa2696bac53bc2598',1,'deviceConnected:&#160;main.cpp'],['../ble_config_8h.html#a5affc02c6814932fa2696bac53bc2598',1,'deviceConnected:&#160;main.cpp']]]
];
