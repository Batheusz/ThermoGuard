var searchData=
[
  ['temperaturachar_0',['TemperaturaChar',['../bleconfig_8cpp.html#ad67a7974fa10bc5742f3e1c5719bdf0b',1,'bleconfig.cpp']]],
  ['temperaturadesc_1',['TemperaturaDesc',['../bleconfig_8cpp.html#a0962a981d8b0fee9f4d0af772bdd319e',1,'bleconfig.cpp']]]
];
