var searchData=
[
  ['botaolasttime_0',['botaoLastTime',['../main_8cpp.html#aea6cbc4ff8e3879ccf35d8f8d5f7ad7d',1,'botaoLastTime:&#160;main.cpp'],['../funcoes_8h.html#aea6cbc4ff8e3879ccf35d8f8d5f7ad7d',1,'botaoLastTime:&#160;main.cpp']]],
  ['botaotime_1',['botaoTime',['../main_8cpp.html#ac8b87eeeb2a6a065bbfb0fd654328442',1,'botaoTime:&#160;main.cpp'],['../funcoes_8h.html#ac8b87eeeb2a6a065bbfb0fd654328442',1,'botaoTime:&#160;main.cpp']]]
];
