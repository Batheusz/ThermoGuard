var searchData=
[
  ['nomewifi_0',['nomeWifi',['../main_8cpp.html#a1985d05d19fdca8123f77df57639188f',1,'nomeWifi:&#160;main.cpp'],['../funcoes_8h.html#a1985d05d19fdca8123f77df57639188f',1,'nomeWifi:&#160;main.cpp']]],
  ['numcelular_1',['numCelular',['../main_8cpp.html#ae5f1bf82db9796145db3a408488ecefd',1,'numCelular:&#160;main.cpp'],['../funcoes_8h.html#ae5f1bf82db9796145db3a408488ecefd',1,'numCelular:&#160;main.cpp']]]
];
