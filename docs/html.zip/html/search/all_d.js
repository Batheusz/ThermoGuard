var searchData=
[
  ['temperaturachar_0',['TemperaturaChar',['../main_8cpp.html#addaafdcebe086b82f5e22ac3ba9b50e2',1,'TemperaturaChar:&#160;main.cpp'],['../bleconfig_8cpp.html#ad67a7974fa10bc5742f3e1c5719bdf0b',1,'TemperaturaChar(BLEUUID((uint16_t) 0x2A6E), BLECharacteristic::PROPERTY_READ|BLECharacteristic::PROPERTY_NOTIFY):&#160;bleconfig.cpp']]],
  ['temperaturadesc_1',['TemperaturaDesc',['../bleconfig_8cpp.html#a0962a981d8b0fee9f4d0af772bdd319e',1,'bleconfig.cpp']]]
];
