var searchData=
[
  ['desconectawifi_0',['DesconectaWifi',['../funcoes_8cpp.html#ac0864cde0bddc4d52913c6a7215a85c8',1,'DesconectaWifi():&#160;funcoes.cpp'],['../funcoes_8h.html#ac0864cde0bddc4d52913c6a7215a85c8',1,'DesconectaWifi():&#160;funcoes.cpp']]]
];
