var searchData=
[
  ['senhawifi_0',['senhaWifi',['../main_8cpp.html#a2b53c380928d42395504a2470d0e10e6',1,'senhaWifi:&#160;main.cpp'],['../funcoes_8h.html#a2b53c380928d42395504a2470d0e10e6',1,'senhaWifi:&#160;main.cpp']]],
  ['server_1',['server',['../main_8cpp.html#a4cfa213c7b6b7e5a1788f5bf87b423d8',1,'server:&#160;main.cpp'],['../funcoes_8h.html#a4cfa213c7b6b7e5a1788f5bf87b423d8',1,'server:&#160;main.cpp']]],
  ['setpointtemp_2',['setpointTemp',['../main_8cpp.html#add1d9118be43175094da2653b50c9f78',1,'setpointTemp:&#160;main.cpp'],['../funcoes_8h.html#add1d9118be43175094da2653b50c9f78',1,'setpointTemp:&#160;main.cpp']]]
];
