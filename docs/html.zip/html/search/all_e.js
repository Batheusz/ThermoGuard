var searchData=
[
  ['ultimatemp_0',['ultimaTemp',['../main_8cpp.html#a88c6be4f27423cb49670a683b86f1685',1,'main.cpp']]]
];
