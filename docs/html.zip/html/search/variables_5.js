var searchData=
[
  ['intervalotemp_0',['intervaloTemp',['../main_8cpp.html#a0410997c46ed3194dd285765f7f31860',1,'intervaloTemp:&#160;main.cpp'],['../funcoes_8h.html#a0410997c46ed3194dd285765f7f31860',1,'intervaloTemp:&#160;main.cpp']]]
];
