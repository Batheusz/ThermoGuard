var searchData=
[
  ['temperaturachar_0',['TemperaturaChar',['../main_8cpp.html#addaafdcebe086b82f5e22ac3ba9b50e2',1,'main.cpp']]]
];
