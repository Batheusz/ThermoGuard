var searchData=
[
  ['service_5fuuid_0',['SERVICE_UUID',['../ble_config_8h.html#a445125ee8c34695376c85f10b38844d6',1,'bleConfig.h']]]
];
