var searchData=
[
  ['apikey_0',['apiKey',['../main_8cpp.html#abafd9aa183f18bceec5da61aa1f93a87',1,'apiKey:&#160;main.cpp'],['../funcoes_8h.html#abafd9aa183f18bceec5da61aa1f93a87',1,'apiKey:&#160;main.cpp']]],
  ['apiwhats_1',['apiWhats',['../main_8cpp.html#a2178705e4b75e3811fb805ea29271cd6',1,'apiWhats:&#160;main.cpp'],['../funcoes_8h.html#a2178705e4b75e3811fb805ea29271cd6',1,'apiWhats:&#160;main.cpp']]]
];
