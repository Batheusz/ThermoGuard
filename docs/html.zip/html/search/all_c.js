var searchData=
[
  ['salvaconfig_0',['SalvaConfig',['../funcoes_8cpp.html#a10c0866444677cfc520f43e52f3b763a',1,'SalvaConfig(String wifi, String senha, float setPoint, uint32_t intervalo):&#160;funcoes.cpp'],['../funcoes_8h.html#a10c0866444677cfc520f43e52f3b763a',1,'SalvaConfig(String wifi, String senha, float setPoint, uint32_t intervalo):&#160;funcoes.cpp']]],
  ['senhawifi_1',['senhaWifi',['../main_8cpp.html#a2b53c380928d42395504a2470d0e10e6',1,'senhaWifi:&#160;main.cpp'],['../funcoes_8h.html#a2b53c380928d42395504a2470d0e10e6',1,'senhaWifi:&#160;main.cpp']]],
  ['server_2',['server',['../main_8cpp.html#a4cfa213c7b6b7e5a1788f5bf87b423d8',1,'server:&#160;main.cpp'],['../funcoes_8h.html#a4cfa213c7b6b7e5a1788f5bf87b423d8',1,'server:&#160;main.cpp']]],
  ['service_5fuuid_3',['SERVICE_UUID',['../ble_config_8h.html#a445125ee8c34695376c85f10b38844d6',1,'bleConfig.h']]],
  ['setpointtemp_4',['setpointTemp',['../main_8cpp.html#add1d9118be43175094da2653b50c9f78',1,'setpointTemp:&#160;main.cpp'],['../funcoes_8h.html#add1d9118be43175094da2653b50c9f78',1,'setpointTemp:&#160;main.cpp']]],
  ['setup_5',['setup',['../main_8cpp.html#a4fc01d736fe50cf5b977f755b675f11d',1,'main.cpp']]]
];
