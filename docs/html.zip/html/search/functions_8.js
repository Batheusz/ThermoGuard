var searchData=
[
  ['salvaconfig_0',['SalvaConfig',['../funcoes_8cpp.html#a10c0866444677cfc520f43e52f3b763a',1,'SalvaConfig(String wifi, String senha, float setPoint, uint32_t intervalo):&#160;funcoes.cpp'],['../funcoes_8h.html#a10c0866444677cfc520f43e52f3b763a',1,'SalvaConfig(String wifi, String senha, float setPoint, uint32_t intervalo):&#160;funcoes.cpp']]],
  ['setup_1',['setup',['../main_8cpp.html#a4fc01d736fe50cf5b977f755b675f11d',1,'main.cpp']]]
];
