var class_my_server_callbacks =
[
    [ "onConnect", "class_my_server_callbacks.html#a9a864448a2836d4381e1bdb6785ba415", null ],
    [ "onDisconnect", "class_my_server_callbacks.html#aa0f35b6d22a036789bd40bf433f86e0d", null ]
];