var hierarchy =
[
    [ "BLEServerCallbacks", null, [
      [ "MyServerCallbacks", "class_my_server_callbacks.html", null ]
    ] ]
];