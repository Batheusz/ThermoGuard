var funcoes_8cpp =
[
    [ "botaoISR", "funcoes_8cpp.html#a98f1875fb179306f570060a93476cf21", null ],
    [ "CarregarConfig", "funcoes_8cpp.html#ae37aeb6cc3ac00302fef48cad121e04a", null ],
    [ "ConectaWifi", "funcoes_8cpp.html#a420a08393185ceba2855a2de10715128", null ],
    [ "DesconectaWifi", "funcoes_8cpp.html#ac0864cde0bddc4d52913c6a7215a85c8", null ],
    [ "EnviarWeb", "funcoes_8cpp.html#a496d1413601446647f4f6e259120b832", null ],
    [ "EnviarWhats", "funcoes_8cpp.html#aab7876312534d1d5cb2b52368d8a66aa", null ],
    [ "SalvaConfig", "funcoes_8cpp.html#a10c0866444677cfc520f43e52f3b763a", null ]
];